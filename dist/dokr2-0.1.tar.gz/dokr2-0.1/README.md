dokr - Make your docker and ecs tasks easy
A Helper pip package for docker and ECS tasks. This pip package helps you automate your CI/CD pipeline. If your using docker and Amazon ECS for deployments, this tool can be really helpful. This package uses aws cli and ecs cli. Mak

Assumptions:
Assuming python is installed on your system.
Docker is installed on your system
aws-cli is installed and credentials are configured on your system.
ecs-cli is installed on system [For Log Command only]
Install dokr on your system using :

pip install dokr
